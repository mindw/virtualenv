from pkg_resources.extern import vendored

vendored(__name__, 'six', 'pkg_resources._vendor')
vendored(__name__, 'six.moves', 'pkg_resources._vendor')
